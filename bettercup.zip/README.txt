A Pen created at CodePen.io. You can find this one at https://codepen.io/joe-watkins/pen/AokJw.

 Wrangling a style guide together for Bootstrap 3